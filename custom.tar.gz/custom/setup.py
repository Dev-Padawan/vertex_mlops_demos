import setuptools

setuptools.setup(

    install_requires=[

        'google-cloud-aiplatform',

  ],

    packages=setuptools.find_packages())
